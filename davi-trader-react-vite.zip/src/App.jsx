export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>🦁 DAVI Trader App</h1>
      <p>Aplicativo carregado com sucesso!</p>
    </div>
  );
}