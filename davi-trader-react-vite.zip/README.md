# DAVI Trader App

Aplicativo React com estrutura padrão Vite + src/, pronto para deploy no Vercel.