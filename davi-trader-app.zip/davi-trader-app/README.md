# DAVI Trader App

Painel funcional com saldo, registro de trades e histórico. Desenvolvido em React + Vite.